import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;


public class IntroPanel extends JPanel {
	
	public IntroPanel(){
		setBackground(Color.green);
		
		add(new JLabel("Layout Manager Demonstration"));
		add(new JLabel("Choose a tabe to see and example" +
				"of a lyout manager."));
	}
}
