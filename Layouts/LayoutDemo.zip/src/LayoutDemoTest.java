import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;


public class LayoutDemoTest {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Layour Demo");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTabbedPane tabPane = new JTabbedPane();
		tabPane.add("Intro", new IntroPanel());
		tabPane.add("Flow", new FlowPanel());
		tabPane.add("Border", new BorderPanel());
		tabPane.add("Grid", new GridPanel());
		tabPane.add("Box", new BoxPanel());
		
		frame.getContentPane().add(tabPane);
		frame.pack();
		frame.setVisible(true);
	}

}
